import sensors

sensors.Switch().start()
