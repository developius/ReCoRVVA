import sensors # import the sensors module
 
sensors.Switch().start() # start listening to the switch
